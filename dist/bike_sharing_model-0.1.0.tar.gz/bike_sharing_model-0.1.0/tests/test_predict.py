import unittest
from unittest.mock import patch, MagicMock
import pandas as pd
import numpy as np
from bike_sharing_model import predict
from bike_sharing_model.config.core import config

class TestPrediction(unittest.TestCase):

    @patch("bike_sharing_model.processing.data_manager.load_pipeline")
    @patch("bike_sharing_model.processing.validation.validate_Inputs")
    def test_make_prediction_valid_input(self, mock_validate_inputs, mock_load_pipeline):

        mock_model = MagicMock()
        mock_model.predict.return_value = np.array([5.0])

        mock_load_pipeline.return_value = mock_model

        mock_validate_inputs.return_value = (
            pd.DataFrame([{
                'dteday': '2011-07-13', 'season': 'fall', 'hr': '4am', 'holiday': 'No',
                'weekday': 'Wed', 'workingday': 'Yes', 'weathersit': 'Clear',
                'temp': 26.78, 'atemp': 28.9988, 'hum': 58.0, 'windspeed': 16.9979,
                'casual': 0, 'registered': 5, 'year': 2012, 'month': 4
            }]),
            None  # No errors
        )

        data_in = {
            'dteday': '2011-07-13', 'season': 'fall', 'hr': '4am', 'holiday': 'No',
            'weekday': 'Wed', 'workingday': 'Yes', 'weathersit': 'Clear',
            'temp': 26.78, 'atemp': 28.9988, 'hum': 58.0, 'windspeed': 16.9979,
            'casual': 0, 'registered': 5, 'year': 2012, 'month': 4
        }

        results = predict.make_prediction(input_data=data_in)

        self.assertIn("predictions", results)
        self.assertEqual(results["predictions"][0], 5.0)  # Expected prediction
        self.assertIn("version", results)

    # @patch("bike_sharing_model.processing.data_manager.load_pipeline")
    # @patch("bike_sharing_model.processing.validation.validate_Inputs")
    # def test_make_prediction_invalid_input(self, mock_validate_inputs, mock_load_pipeline):
    #
    #     mock_model = MagicMock()
    #     mock_model.predict.return_value = [0]
    #     mock_load_pipeline.return_value = mock_model
    #
    #     invalid_data_dict = {col: None for col in config.model_config_.features}
    #     invalid_data_dict["temp"] = "invalid_value"
    #
    #     invalid_df = pd.DataFrame([invalid_data_dict])
    #     mock_validate_inputs.return_value = (invalid_df, {"error": "'>=' not supported between instances of 'str' and 'float'"})
    #
    #     result = predict.make_prediction(input_data=invalid_data_dict)
    #
    #     self.assertIn("predictions", result)
    #     self.assertEqual(result["predictions"], None)
    #     self.assertIn("version", result)
    #     self.assertNotEqual(result["version"], None)


if __name__ == "__main__":
    unittest.main()